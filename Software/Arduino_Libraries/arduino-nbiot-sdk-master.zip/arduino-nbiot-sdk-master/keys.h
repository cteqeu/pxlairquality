/****
 * Enter your AllThingsTalk device credentials below
 */
#ifndef KEYS_h
#define KEYS_h
const char* DEVICE_ID = "";
const char* DEVICE_TOKEN = "";
const char* APN = "starter.att.iot";
#endif